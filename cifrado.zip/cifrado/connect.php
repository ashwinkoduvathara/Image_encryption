<?php 
$servername="localhost";
$username="root";
$password="";
$database="imgenc";
$con=mysqli_connect($servername,$username,$password,$database);
if (!$con) 
{
echo "connection failed";
}
/*else
{
echo "Success";	
}*/

?>