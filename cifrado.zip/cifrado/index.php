<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Cifrado</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Unique Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="Webpage/css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="Webpage/css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="Webpage/css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Code+Pro:200,300,400,500,600,700,900&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<header>
		<!-- menu -->
		<ul id="menu">
			<li>
				<input id="check02" type="checkbox" name="menu" />
				<label for="check02"><span class="fa fa-bars" aria-hidden="true"></span></label>
				<ul class="submenu">
					<li><a href="index.php" class="active">Home</a></li>
					<li><a href="Login/log.php">Login</a></li>
					<li><a href="Webpage/services.php">Services</a></li>
					<li><a href="Webpage/contact.php">Contact Us</a></li>
					<li><a href="Webpage/about.php">About Us</a></li>
					<li><a href="Webpage/team.php">The Team</a></li>
					
				</ul>
			</li>
		</ul>
		<!-- //menu -->
	</header>
	<!-- //header -->

	<!-- banner -->
	<div class="banner_w3lspvt he-codes">
		<div class="container-fluid">
			<div class="banner-text pl-lg-5 pl-sm-4 ml-lg-3">
				<div class="logo-2">
					<a href="index.php"><span class="fa fa-stumbleupon"></span></a>
				</div>
				<h1 class="my-md-4 my-3">Cifrado</h1>
				<h2>THINK,THEN CLICK,</h2>
				<h2>Not the other way around.</h2>
				<h2>One single vulnerability is all an attacker needs.</h2>
				<h2>At the end of the day the goals are simple: Safety and Security.</h2>
				<a href="Webpage/about.php" class="btn button-style mt-5">Read More</a>
				<a href="Webpage/contact.php" class="btn button-style mt-5">Contact Us</a>
			</div>
		</div>
		<!-- copyright 
		<div class="wthree_copy_right text-right ml-auto mr-sm-5 mr-4">
			<p class="text-li">© 2019 Unique. All rights reserved | Design by
				<a href="http://w3layouts.com/" class="text-wh font-weight-bold">W3layouts</a>
			</p>
		</div>-->
		<!-- //copyright -->
	</div>
	<!-- //banner -->

</body>

</html>