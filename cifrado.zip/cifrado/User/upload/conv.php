<?php
if (isset($_POST['action'])) 
{
    
function convertImage($file, $ofile, $quality)
{
    // jpg, png, gif or bmp?
    $exploded = explode('.',$file);
    $ext = $exploded[count($exploded) - 1]; 

    if (preg_match('/jpg|jpeg/i',$ext))
        $imageTmp=imagecreatefromjpeg($file);
    else if (preg_match('/png/i',$ext))
        $imageTmp=imagecreatefrompng($file);
    else if (preg_match('/gif/i',$ext))
        $imageTmp=imagecreatefromgif($file);
    else if (preg_match('/bmp/i',$ext))
        $imageTmp=imagecreatefrombmp($file);
    else
        return 0;

    // quality is a value from 0 (worst) to 100 (best)
    imagejpeg($imageTmp, $ofile, $quality);
    imagedestroy($imageTmp);

    return 1;
}


 ?>


<html>
  <head>

    <title>Convert Image</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-md-12" >
          
        </div>
      </div>
      <?php if ($error != '') { ?>
      <div class="row">
        <div class="col-12 alert alert-danger" role="alert">
          <?php echo ($error); ?>
        </div>
      </div>
      <?php } ?>
      <div class="panel" style="box-shadow: 8px 4px 14px black; border-radius: 10px; margin: 30px;">
        <div class="panel-heading">
          <h1 class="text-center">Image Converter</h1>
        </div>
        <div class="panel-body">
          <form class="form" enctype="multipart/form-data" method="post"  id="form1" name="form1" auto-complete="off" style="padding: 20px;margin: 20px;">
        <div class="form-row">
          <div class="form-group">
            <label for="file">File</label>
            <input type="file" name="file" id="file" placeholder="Choose a file" required class="form-control-file"/>
          </div>
        </div>
        <div class="form-row">
          <button type="submit" class="btn btn-primary" >Convert</button>
          <button type="reset" class="btn btn-reset">Reset</button>
         </div>
      </form>
        </div>
      </div>
    </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
        $("#form1").trigger("reset");
        $("#form1").on("submit",function(e) {
          if ($("#action").val()==0) {
            alert('Select a Valid Action');
            $("#action").focus();
            e.preventDefault();
          }
        })
      })
    </script>
 </div>
    <center><a href="../index.php" class="btn btn-primary">Back To Home</a></center>
</div>
  </body>
</html>