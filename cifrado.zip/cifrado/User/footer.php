<!-- copyright -->
		<div class="wthree_copy_right text-right ml-auto mr-sm-5 mr-4">
			<p class="text-li">
				
			</p>
		</div>
		<!-- //copyright -->
	</div>
	<!-- //banner -->
	</body>
</html>