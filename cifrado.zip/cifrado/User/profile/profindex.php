<?php 
session_start();
include_once '../connect.php';
$uid=$_SESSION['user_id'];
$sql="SELECT * FROM login l,registration r WHERE l.user_id=r.user_id AND l.user_id='$uid'";
$res=mysqli_query($con,$sql);
$row=mysqli_fetch_array($res);
if (isset($_POST['btn'])) {
    $name=$_POST['txtName'];
    $mobile=$_POST['txtMobile'];
    $sql="UPDATE registration SET fullname='$name',mobile='$mobile' WHERE user_id='$uid'";
    if (mysqli_query($con,$sql)) {
        ?>
        <script type="text/javascript">
            alert('Success');
            window.location='profindex.php';
        </script>
        <?php
    }
}
 ?>
<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
body {
  background: #F1F3FA;
}

/* Profile container */
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 20px;
  background: #fff;
  min-height: 460px;
}
    </style>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <title>My Profile</title>
</head>
<body>
<div class="container">
    <div class="row profile">
        

        
        <div class="col-md-3"></div>
        <?php 
            if (isset($_GET['edit'])) {
                ?>
                <div class="col-md-6">
            <div class="profile-content">
               <div class="container">
                   <div class="row">
                       <div class="col-md-6">
                        <h2 class="text-center">
                            My Profile
                        </h2>
                        <div class="profile-userpic">
                    <img src="https://www.seekpng.com/png/detail/428-4287240_no-avatar-user-circle-icon-png.png" class="img-responsive" alt="">
                </div>
                           <form class="form-group" method="POST">
                            <label>Full Name</label>
                               <input type="text" name="txtName" class="form-control" value="<?php echo $row['fullname'] ?>">
                               <label>Mobile</label>
                               <input type="text" name="txtMobile" class="form-control" value="<?php echo $row['mobile'] ?>">
                               <br>
                               <button type="submit" name="btn" class="btn btn-primary btn-block">Update</button>
                           </form>
                       </div>
                       <div class="col-md-3"></div>
                   </div>
               </div>
            </div>
            <center><a href="../">Back To Home</a></center>
            </div>
                <?php
            }else{
             ?>
        <div class="col-md-6">
            <div class="profile-sidebar">
                <!-- SIDEBAR USERPIC -->
                <div class="profile-userpic">
                    <img src="https://www.seekpng.com/png/detail/428-4287240_no-avatar-user-circle-icon-png.png" class="img-responsive" alt="">
                </div>
                <!-- END SIDEBAR USERPIC -->
                <!-- SIDEBAR USER TITLE -->

                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">
                       <?php echo $row['fullname'] ?>
                    </div>
                    <div class="profile-usertitle-job">
                        <?php echo $row['email'] ?>
                    </div>
                </div>
                <!-- END SIDEBAR USER TITLE -->
                <!-- SIDEBAR BUTTONS -->
                <div class="profile-userbuttons">
                    <a href="profindex.php?edit=1" class="btn btn-success btn-sm">Edit</a>
                   
                </div>
                <!-- END SIDEBAR BUTTONS -->
                <!-- SIDEBAR MENU -->
                <div class="profile-usermenu">
                    <ul class="nav">
                       
                        <li class="active">
                            <a href="#">
                            <i class="glyphicon glyphicon-user"></i>
                            <?php echo $row['fullname'] ?> </a>
                        </li>
                        <li>
                            <a href="#" target="_blank">
                            <i class="glyphicon glyphicon-ok"></i>
                            <?php echo $row['email'] ?> </a>
                        </li>
                        <li>
                            <a href="#">
                            <i class="glyphicon glyphicon-flag"></i>
                            <?php echo $row['mobile'] ?> </a>
                        </li>
                    </ul>
                </div>
                <!-- END MENU -->
            </div>
            <center><a href="../">Back To Home</a></center>
        </div>
       <?php } ?> 
    </div>
</div>
</body>
</html>