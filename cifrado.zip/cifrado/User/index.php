<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php  
require_once"../User/header.php";
?>

	<div class="banner_w3lspvt he-codes">
		<div class="container-fluid">
			<div class="banner-text pl-lg-5 pl-sm-4 ml-lg-3">
				<div class="logo-2">
					<a href="../User/index.php"><span class="fa fa-stumbleupon"></span></a>
				</div>
				<h1 class="my-md-4 my-3">Cifrado</h1>
				<h2>THINK,THEN CLICK,</h2>
				<h2>Not the other way around.</h2>
				<h2>One single vulnerability is all an attacker needs.</h2>
				<h2>At the end of the day the goals are simple: Safety and Security.</h2>
				<a href="about.php" class="btn button-style mt-5">Read More</a>
				<a href="contact.php" class="btn button-style mt-5">Contact Us</a>
			</div>
		</div>

<?php  
require_once"../User/footer.php";
?>
