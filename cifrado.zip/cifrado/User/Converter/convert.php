<?php 

//import the converter class
require('image_converter.php');

$imageType = '';
$download = false;

//handle get method, when page redirects
if($_GET){	
	$imageType = urldecode($_GET['imageType']);
	$imageName = urldecode($_GET['imageName']);
}else{
	header('Location:index.php');
}

//handle post method when the form submitted
if($_POST){
	
	$convert_type = $_POST['convert_type'];
	
	//create object of image converter class
	$obj = new Image_converter();
	$target_dir = 'uploads';
	//convert image to the specified type
	$image = $obj->convert_image($convert_type, $target_dir, $imageName);
	
	//if converted activate download link 
	if($image){
		$download = true;
	}
}


//convert types
$types = array(
	'png' => 'PNG',
	'jpg' => 'JPG',
	'gif' => 'GIF',
);
?>
<html>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
img{
	max-width: 360px;
}
body{
	background: lightgray;
}
 
</style>
</head>
<body>
	<?php if(!$download) {?>
		<div class="container">
			<div class="row" style="margin-top: 25px;">
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<h3 class="text-center">
								Conversion Format
							</h3>
						</div>
						<div class="card-body">
							<form method="post" action="" class="form-group">
			
						<img src="uploads/<?php echo $imageName;?>" class="img-thumbnail"  />
					
						<label for="convert_type">Convert To: </label>
							<select name="convert_type" id="convert_type" class="form-control">
								<?php foreach($types as $key=>$type) {?>
									<?php if($key != $imageType){?>
									<option value="<?php echo $key;?>"><?php echo $type;?></option>
									<?php } ?>
								<?php } ?>
							</select>
							<br /><br />
					<input type="submit" value="convert" class="btn btn-primary btn-block" />
		                 </div>
   						 <center><a href="../index.php" class="btn btn-primary">Back To Home</a></center>
						 </div>
		                 </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<?php if($download) {?>
		<div class="container">
			<div class="row" style="margin-top: 25px;">
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<h3 class="text-center">
								Image Converted to <?php echo ucwords($convert_type); ?>
							</h3>
						</div>
						<div class="card-body">
							
						<img src="<?php echo $target_dir.'/'.$image;?>" class="img-thumbnail"  />
					
					<a href="download.php?filepath=<?php echo $target_dir.'/'.$image; ?>" class="btn btn-primary btn-block" />Download Converted Image</a>
				<a href="index.php" class="btn btn-primary btn-block">Convert Another</a>
						</div>
						</div>
    					<center><a href="../index.php" class="btn btn-primary">Back To Home</a></center>
						</div>			
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</html>