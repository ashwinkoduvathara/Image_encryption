<?php
include_once '../Webpage/connect.php';
include_once '../Admin/header.php';
$id=$_GET["id"];
$sql="delete from registration where user_id='$id'";
$sql1="delete from login where user_id='$id'";
if(mysqli_query($con,$sql))
{
	if(mysqli_query($con,$sql1))
	{
	?>
	<script type="text/javascript">
		alert('deleted');
		window. location='userlist.php';
	</script>
	<?php
}
}
?>