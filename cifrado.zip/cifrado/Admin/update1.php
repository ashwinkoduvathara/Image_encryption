<?php
include_once '../Webpage/connect.php';
$id=$_GET['id'];
?>
<?php
if(isset($_POST['btn']))
{

$uname=$_POST['uname'];
$pass=$_POST['pswd'];
$sql="update login set email='$uname',password='$pass' where user_id='$id'";
if(mysqli_query($con,$sql))
{
	?>
<script type="text/javascript">
alert("updated");
window.location='userlist.php';
</script>
<?php
}
}
$sql1="select * from login where user_id='$id'";
$result=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result);
include_once 'header.php';

?>
<div class="container">
<div class="row">
<div class="col-md-6">
<form class="form-group" method="POST">
<label>username</label>
<input type="text" name="uname" class="form-control" value=<?php echo $row['email']?>>
</label>password</label>
<input type="text" name="pswd" class="form-control" value=<?php echo $row['password']?>>
<br>
<button type="submit" name="btn" class="btn btn-primary btn-block">update</button>
</form>
</div>
</div>
</div>
<?php include_once  'footer.php'?>