<?php
include_once '../Webpage/connect.php';
include_once '../Admin/header.php';
$id=$_GET["id"];
if(isset($_POST['btn']))
{
$email=$_POST['email'];
$pass=$_POST['pass'];
$sql="update login set email='$email',password='$pass' where user_id=$id";
echo $sql;
if(mysqli_query($con,$sql))
{
	?>
<script type="text/javascript">
alert("updated");
window.location('userlist.php');
</script>
<?php
}
}
$sql1=" select * from login where user_id='$id' ";
echo $sql1;
$result=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result);
include_once 'header.php';
?>
<div class="container">
<div class="row">
<div class="col-md-6">
<form class="form-group" method="POST">
<label>Email</label>
<input type="text" name="email" class="form-control" value="<?$row['email']?>">
</label>Password</label>
<input type="text" name="pass" class="form-control" value="<?$row['password']?>">
<br>
<button type="submit" name="btn" class="btn btn-primary btn-block">update</button>
</form>
</div>
</div>
</div>
<?php include_once  '../Admin/footer.php'?>