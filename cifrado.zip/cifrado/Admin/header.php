<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Unique Multipurpose Flat Bootstrap Responsive Website Template | Home :: W3layouts</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Unique Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->
    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" type="text/css"/>	
    
	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Code+Pro:200,300,400,500,600,700,900&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<header>
		<!-- menu -->
		<ul id="menu">
			<li>
				<input id="check02" type="checkbox" name="menu" />
				<label for="check02"><span class="fa fa-bars" aria-hidden="true"></span></label>
				<ul class="submenu">
					<li><a href="../Admin/index.php" class="active">Home</a></li>
					<li><a href="../Admin/apprlist.php">Account Approval</a></li>
					<li><a href="../Admin/userlist.php">User Details</a></li>
					<li><a href="../Admin/imgdet.php">Image Details</a></li>
					<li><a href="../Admin/logout.php">Logout</a></li>
					
				</ul>
			</li>
		</ul>
		<!-- //menu -->
	</header>
	<br>