<?php
include_once '../Webpage/connect.php';
include_once 'header.php';
?>
<div class="container">
  <div  class="row">
    <div class="col-md-12">
      <table class="table table-bordered" id="mytable">
        <thead>
          <th>Sno</th>
          <th> Imageid </th>       
          <th> Imagename </th>
          <th> Format </th>
          <th> Operation </th>
          <th> Userid </th>
          <th></th>
        </thead>
        <tbody>
        <?php 
        $sql0="select * from imgdet ";
        $i=1;
        $result=mysqli_query($con,$sql0);
        while($row=mysqli_fetch_array($result))
        {
        
        echo "<tr>";
          echo "<td>".$i."</td>";
          echo "<td>".$row["img_id"]."</td>";
          echo "<td> ".$row["imgname"]."</td>";
          echo "<td> ".$row["format"]."</td>";
           echo "<td> ".$row["opt"]."</td>";
          echo "<td> ".$row["user_id"]."</td>";
          ?>
          <td>
            <a class="btn btn-danger" href="../Admin/imgdel.php?img=<?php echo $row['imgname']?>"
            onclick="return confirm('do you want to delete?')">
            delete
          </td>
        </tr>
        <?php
        $i++;
      }
      ?>
    </tbody>
  </table>
</div>
</div>
</div>
<?php include_once '../Admin/footer.php';

?>
<script type="text/javascript">
  $(document).ready(function()
  {
    $('#mytable').DataTable();
  });
</script>
  