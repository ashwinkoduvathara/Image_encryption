<?php
include_once '../Webpage/connect.php';
include_once '../Admin/header.php';
$img=$_GET["img"];
$sql="delete from imgdet where imgname='$img'";

if(mysqli_query($con,$sql))
{
		?>
	<script type="text/javascript">
		alert('deleted');
		window. location='imgdet.php';
	</script>
	<?php
}
?>