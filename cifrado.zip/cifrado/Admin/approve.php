<?php
include_once '../Webpage/connect.php';
include_once '../Admin/header.php';
$id=$_GET["id"];
$sql="update login set status=1 where user_id='$id'";
if(mysqli_query($con,$sql))
{
	?>
	<script type="text/javascript">
		alert('approved');
		window. location='apprlist.php';
	</script>
	<?php
}
?>