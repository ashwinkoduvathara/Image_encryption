<?php
include_once '../Webpage/connect.php';
include_once 'header.php';
?>
<div class="container">
	<div  class="row">
		<div class="col-md-12">
			<table class="table table-bordered" id="mytable">
				<thead>
					<th>Sno</th>
					<th> Reg_id </th>
					<th> User_id </th>				
					<th> Fullname </th>
					
					
					<th></th>
				</thead>
				<tbody>
				<?php 
				$sql2="select * from registration,login where registration.user_id=login.user_id and status=0 ";
				$i=1;
				$result=mysqli_query($con,$sql2);
				while($row=mysqli_fetch_array($result))
				{
				
				echo "<tr>";
					echo "<td>".$i."</td>";
					echo "<td>".$row["reg_id"]."</td>";
					echo "<td>".$row["user_id"]."</td>";
					echo "<td> ".$row["fullname"]."</td>";
					//echo "<td> ".$row["email"]."</td>";
					//echo "<td> ".$row["gender"]."</td>";
					//<td> <?=$row["mno"] </td>
					//<td> <?=$row["gen"] </td>
					?>
					<td>
						
						<a class="btn btn-info" href="../Admin/approve.php?id=<?php echo $row['user_id']?>"
							onclick="return confirm('do you want to Approve?')">
						approve</a>
					</td>
				</tr>
				<?php
				$i++;
			}
			?>
		</tbody>
	</table>
</div>
</div>
</div>
<?php include_once '../Admin/footer.php';

?>
<script type="text/javascript">
	$(document).ready(function()
	{
		$('#mytable').DataTable();
	});
</script>
	