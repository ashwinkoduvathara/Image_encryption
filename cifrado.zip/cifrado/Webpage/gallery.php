<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Unique Multipurpose Flat Bootstrap Responsive Website Template | Gallery :: W3layouts</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Unique Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Code+Pro:200,300,400,500,600,700,900&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<header>
		<div class="logo ml-sm-4 ml-2 mt-3">
			<a href="../index.php"><span class="fa fa-stumbleupon"></span></a>
		</div>
		<!-- menu -->
		<ul id="menu">
			<li>
				<input id="check02" type="checkbox" name="menu" />
				<label for="check02"><span class="fa fa-bars" aria-hidden="true"></span></label>
				<ul class="submenu">
					<li><a href="../index.php">Home</a></li>
					<li><a href="../Login/log.php">Login</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="team.php">The Team</a></li>
					<li><a href="gallery.php" class="active">Gallery</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</li>
		</ul>
		<!-- //menu -->
	</header>
	<!-- //header -->

	<!-- gallery -->
	<div class="gallery he-codes">
		<!-- gallery content -->
		<div class="gallery-cont text-center pt-5">
			<h3 class="title text-center text-wh font-weight-bold">Our Gallery</h3>
			<div class="container pt-5">
				<div class="row news-grids text-center no-gutters">
					<div class="col-md-4 gal-img">
						<a href="#gal1"><img src="images/g1.jpg" alt="Gallery Image" class="img-fluid"></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href="#gal2"><img src="images/g2.jpg" alt="Gallery Image" class="img-fluid"></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href="#gal3"><img src="images/g3.jpg" alt="Gallery Image" class="img-fluid"></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href="#gal4"><img src="images/g4.jpg" alt="Gallery Image" class="img-fluid"></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href="#gal5"><img src="images/g5.jpg" alt="Gallery Image" class="img-fluid"></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href="#gal6"><img src="images/g6.jpg" alt="Gallery Image" class="img-fluid"></a>
					</div>
				</div>
			</div>
		</div>
		<!-- gallery popups -->
		<!-- popup-->
		<div id="gal1" class="pop-overlay animate">
			<div class="popup">
				<img src="images/g1.jpg" alt="Popup Image" class="img-fluid" />
				<h1 class="mt-4">Nulla viverra pharetra se, eget pulvinar neque pharetra ac int. placerat placerat dolor.</h1>
				<a class="close" href="#gallery">&times;</a>
			</div>
		</div>
		<!-- //popup -->
		<!-- popup-->
		<div id="gal2" class="pop-overlay animate">
			<div class="popup">
				<img src="images/g2.jpg" alt="Popup Image" class="img-fluid" />
				<h2 class="mt-4">Nulla viverra pharetra se, eget pulvinar neque pharetra ac int. placerat placerat dolor.</h2>
				<a class="close" href="#gallery">&times;</a>
			</div>
		</div>
		<!-- //popup -->
		<!-- popup-->
		<div id="gal3" class="pop-overlay animate">
			<div class="popup">
				<img src="images/g3.jpg" alt="Popup Image" class="img-fluid" />
				<p class="mt-4">Nulla viverra pharetra se, eget pulvinar neque pharetra ac int. placerat placerat dolor.</p>
				<a class="close" href="#gallery">&times;</a>
			</div>
		</div>
		<!-- //popup3 -->
		<!-- popup-->
		<div id="gal4" class="pop-overlay animate">
			<div class="popup">
				<img src="images/g4.jpg" alt="Popup Image" class="img-fluid" />
				<p class="mt-4">Nulla viverra pharetra se, eget pulvinar neque pharetra ac int. placerat placerat dolor.</p>
				<a class="close" href="#gallery">&times;</a>
			</div>
		</div>
		<!-- //popup -->
		<!-- popup-->
		<div id="gal5" class="pop-overlay animate">
			<div class="popup">
				<img src="images/g5.jpg" alt="Popup Image" class="img-fluid" />
				<p class="mt-4">Nulla viverra pharetra se, eget pulvinar neque pharetra ac int. placerat placerat dolor.</p>
				<a class="close" href="#gallery">&times;</a>
			</div>
		</div>
		<!-- //popup -->
		<!-- popup-->
		<div id="gal6" class="pop-overlay animate">
			<div class="popup">
				<img src="images/g6.jpg" alt="Popup Image" class="img-fluid" />
				<p class="mt-4">Nulla viverra pharetra se, eget pulvinar neque pharetra ac int. placerat placerat dolor.</p>
				<a class="close" href="#gallery">&times;</a>
			</div>
		</div>
		<!-- //popup -->
		<!-- //gallery popups -->
		<!-- //gallery -->
		<!-- //gallery content -->
		<!-- copyright -->
		<div class="wthree_copy_right text-right ml-auto mt-5 mr-sm-5 mr-4">
			<p class="text-li">© 2019 Unique. All rights reserved | Design by
				<a href="http://w3layouts.com/" class="text-wh font-weight-bold">W3layouts</a>
			</p>
		</div>
		<!-- //copyright -->
	</div>
	<!-- //gallery -->

</body>

</html>