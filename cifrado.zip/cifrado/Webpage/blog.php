<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Unique Multipurpose Flat Bootstrap Responsive Website Template | Blog :: W3layouts</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Unique Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Code+Pro:200,300,400,500,600,700,900&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<header>
		<div class="logo blog-clr ml-sm-4 ml-2 mt-3">
			<a href="../index.php"><span class="fa fa-stumbleupon"></span></a>
		</div>
		<!-- menu -->
		<ul id="menu">
			<li>
				<input id="check02" type="checkbox" name="menu" />
				<label for="check02"><span class="fa fa-bars" aria-hidden="true"></span></label>
				<ul class="submenu">
					<li><a href="../index.php">Home</a></li>
					<li><a href="../Login/log.php">Login</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="team.php">The Team</a></li>
					<li><a href="blog.php" class="active">Blog</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</li>
		</ul>
		<!-- //menu -->
	</header>
	<!-- //header -->

	<!-- blog -->
	<div class="blog he-codes">
		<!-- blog content -->
		<div class="blog-cont pt-5">
			<h3 class="title text-center text-bl font-weight-bold">Our Blog</h3>
			<div class="container pt-5">
				<div class="row pt-2">
					<!-- blog grid -->
					<div class="col-lg-4 col-md-6">
						<div class="card border-0 med-blog">
							<div class="card-header p-0">
								<a href="#">
									<img class="card-img-bottom" src="images/blog2.jpg" alt="Card image cap">
								</a>
							</div>
							<div class="card-body border border-top-0">
								<div class="mb-3">
									<h1 class="blog-title card-title font-weight-bold m-0">
										<a href="#">Dictum porta auris</a>
									</h1>
									<div class="blog_w3icon">
										<span>
											Jan 03,2019 - loremipsum</span>
									</div>
								</div>
								<p class="mb-4">Cras ultricies ligula sed magna dictum porta auris blandita.</p>
								<a href="#" class="blog-btn btn">Read More</a>
							</div>
						</div>
					</div>
					<!-- //blog grid -->
					<!-- blog grid -->
					<div class="col-lg-4 col-md-6 mt-md-0 mt-5">
						<div class="card border-0 med-blog">
							<div class="card-header p-0">
								<a href="#">
									<img class="card-img-bottom" src="images/blog1.jpg" alt="Card image cap">
								</a>
							</div>
							<div class="card-body border border-top-0">
								<div class="mb-3">
									<h2 class="blog-title card-title font-weight-bold m-0">
										<a href="#">Dictum porta auris</a>
									</h2>
									<div class="blog_w3icon">
										<span>
											Jan 06, 2019 - loremipsum</span>
									</div>
								</div>
								<p class="mb-4">Cras ultricies ligula sed magna dictum porta auris blandita.</p>
								<a href="#" class="blog-btn btn">Read More</a>
							</div>
						</div>
					</div>
					<!-- //blog grid -->
					<!-- blog grid -->
					<div class="col-lg-4 col-md-6 mt-lg-0 mt-5 mx-lg-0 mx-md-auto">
						<div class="card border-0 med-blog">
							<div class="card-header p-0">
								<a href="#">
									<img class="card-img-bottom" src="images/blog3.jpg" alt="Card image cap">
								</a>
							</div>
							<div class="card-body border border-top-0">
								<div class="mb-3">
									<h5 class="blog-title card-title font-weight-bold m-0">
										<a href="#">Dictum porta auris</a>
									</h5>
									<div class="blog_w3icon">
										<span>
											Jan 07, 2019 - loremipsum</span>
									</div>
								</div>
								<p class="mb-4">Cras ultricies ligula sed magna dictum porta auris blandita.</p>
								<a href="#" class="blog-btn btn">Read More</a>
							</div>
						</div>
					</div>
					<!-- //blog grid -->
				</div>
			</div>
		</div>
		<!-- //blog content -->
		<!-- copyright -->
		<div class="wthree_copy_right text-right ml-auto mt-5 mr-sm-5 mr-4">
			<p class="text-bl">© 2019 Unique. All rights reserved | Design by
				<a href="http://w3layouts.com/" class="text-bl font-weight-bold">W3layouts</a>
			</p>
		</div>
		<!-- //copyright -->
	</div>
	<!-- //blog -->

</body>

</html>