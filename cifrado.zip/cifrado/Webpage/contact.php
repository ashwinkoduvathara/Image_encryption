<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Unique Multipurpose Flat Bootstrap Responsive Website Template | Contact Us :: W3layouts</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Unique Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Code+Pro:200,300,400,500,600,700,900&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<header>
		<div class="logo ml-sm-4 ml-2 mt-3">
			<a href="../index.php"><span class="fa fa-stumbleupon"></span></a>
		</div>
		<!-- menu -->
		<ul id="menu">
			<li>
				<input id="check02" type="checkbox" name="menu" />
				<label for="check02"><span class="fa fa-bars" aria-hidden="true"></span></label>
				<ul class="submenu">
					<li><a href="../index.php">Home</a></li>
					<li><a href="../Login/log.php">Login</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="team.php">The Team</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="contact.php" class="active">Contact Us</a></li>
				</ul>
			</li>
		</ul>
		<!-- //menu -->
	</header>
	<!-- //header -->

	<!-- contact -->
	<div class="contact he-codes">
		<!-- contact content -->
		<div class="contact-cont pt-5 pb-xl-5 pb-3">
			<h3 class="title text-center text-wh font-weight-bold">Contact Us</h3>
			<div class="container pt-5">
				<div class="row mail-w3l-w3pvt- mt-xl-4">
					<div class="col-lg-6">
						<div class="w3pvt-info_mail_grid_right">
							<form action="#" method="post">
								<div class="form-group">
									<input type="text" name="Name" class="form-control" placeholder="Name" required="">
								</div>
								<div class="form-group">
									<input type="email" name="Email" class="form-control" placeholder="Email" required="">
								</div>
								<div class="form-group">
									<textarea name="Message" placeholder="Message......." required=""></textarea>
								</div>
								<button type="submit" class="btn">Submit</button>
							</form>
						</div>
					</div>
					<div class="col-lg-5 mt-lg-0 mt-5">
						<div class="contact-left-w3ls p-5">
							<h1>Contact Info</h1>
							<div class="row visit">
								<div class="col-md-2 col-sm-2 col-2 contact-icon-wthree">
									<span class="fa fa-home" aria-hidden="true"></span>
								</div>
								<div class="col-md-10 col-sm-10 col-10 contact-text-w3pvt-info">
									<h2>Visit us</h2>
									<p>Parma Via Modena,BO, Italy</p>
									<p>Lorem ipsum dolor.</p>
								</div>
							</div>
							<div class="row mail-w3 my-4">
								<div class="col-md-2 col-sm-2 col-2 contact-icon-wthree">
									<span class="fa fa-envelope-o" aria-hidden="true"></span>
								</div>
								<div class="col-md-10 col-sm-10 col-10 contact-text-w3pvt-info">
									<h4>Mail us</h4>
									<p><a href="mailto:info@example.com">info@example.com</a></p>
								</div>
							</div>
							<div class="row call">
								<div class="col-md-2 col-sm-2 col-2 contact-icon-wthree">
									<span class="fa fa-phone" aria-hidden="true"></span>
								</div>
								<div class="col-md-10 col-sm-10 col-10 contact-text-w3pvt-info">
									<h4>Call us</h4>
									<p>+18044261149</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- //contact content -->
		<!-- copyright -->
		<div class="wthree_copy_right text-right ml-auto mt-5 mr-sm-5 mr-4">
			<p class="text-li">© 2019 Unique. All rights reserved | Design by
				<a href="http://w3layouts.com/" class="text-wh font-weight-bold">W3layouts</a>
			</p>
		</div>
		<!-- //copyright -->
	</div>
	<!-- //contact -->

</body>

</html>