<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="POST">
	Full Name:<input type="text" name="fname">
	<br>
	Mobile No.:<input type="text" name="mno">
	<br>
	Gender:
	<input type="radio" name="gen" value="Male">Male
    <input type="radio" name="gen" value="Female">Female
    <br>
    Email:<input type="text" name="email">
	<br>
	Password:<input type="password" name="pass">
	<br>
    <input type="submit" name="sub" value="Submit">
    <input type="reset" name="res" value="Reset">
</form>
<?php
  require_once 'connect.php';
  if (isset($_POST["sub"])) 
  {
  	$name=$_POST["fname"];
  	$mob=$_POST["mno"];
  	$gen=$_POST["gen"];
  	$user=$_POST["email"];
  	$psw=$_POST["pass"];
  	$sql="select * from login where email='$user'";
  	
  	$result=mysqli_query($con,$sql);
  	if(mysqli_num_rows($result)>0)
  	  {
  	  	echo "User already exists";
  	  }  
  	else
  	  {
  	 		$sql1="insert into login(email,password,type,status) values('$user','$psw','user',0)";
  	 		if(mysqli_query($con,$sql1))
  	 		{
  	 			$uid=$con->insert_id;
  	 			 $sql2="insert into registration(fullname,mobile,gender,user_id) values('$name','$mob','$gen',$uid)";
			  		if(mysqli_query($con,$sql2))
			  	    {
			  	  	 echo "Inserted successfully";
			  	  	}  
  	 		}
  	
  	  }
  	}  
 ?>
</body>
</html>