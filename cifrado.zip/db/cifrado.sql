/*
SQLyog Community v13.1.2 (64 bit)
MySQL - 5.5.8-log : Database - imgenc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`imgenc` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `imgenc`;

/*Table structure for table `imgdet` */

DROP TABLE IF EXISTS `imgdet`;

CREATE TABLE `imgdet` (
  `img_id` int(11) NOT NULL AUTO_INCREMENT,
  `imgname` varchar(100) DEFAULT NULL,
  `format` varchar(15) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `opt` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`img_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

/*Data for the table `imgdet` */

insert  into `imgdet`(`img_id`,`imgname`,`format`,`user_id`,`opt`) values 
(36,'u9AVLry.jpg','image/jpeg',14,'c'),
(37,'u9AVLry.jpg.crypto','application/oct',14,'d');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`user_id`,`email`,`password`,`type`,`status`) values 
(1,'admin@gmail.com','admin','admin',1),
(13,'sugu1234@gmail.com','sugusugu','user',1),
(14,'josh@gmail.com','123456','user',1),
(15,'jose@gmail.com','88889999','user',0),
(16,'gary@gmail.com','88888888','user',0);

/*Table structure for table `registration` */

DROP TABLE IF EXISTS `registration`;

CREATE TABLE `registration` (
  `reg_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`reg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

/*Data for the table `registration` */

insert  into `registration`(`reg_id`,`fullname`,`mobile`,`gender`,`user_id`) values 
(0,'sugumon','7894561238','Male',13),
(10,'Joshua Renjith','9876547892','Male',14),
(11,'Jose John','9876098712','Male',15),
(12,'Gary','8898776612','Male',16);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
